from django.db.models import Q
from django.shortcuts import render, redirect
from .models import League, Team, Player

from . import team_maker

def index(request):
	context = {
		"leagues": League.objects.all(),
		"baseball_leagues": League.objects.filter(sport__icontains='baseball'),
		"womens_leagues": League.objects.filter(name__icontains='women'),
		"hockey_leagues": League.objects.filter(sport__icontains='hockey'),
		"nofootball_leagues": League.objects.exclude(sport__icontains='football'),
		"conference_leagues": League.objects.filter(name__icontains='conference'),
		"atlantic_region_leagues": League.objects.filter(name__icontains='atlantic'),
		"dallas_teams": Team.objects.filter(location__icontains='dallas'),
		"raptors_teams": Team.objects.filter(team_name__icontains='raptors'),
		"city_teams": Team.objects.filter(location__icontains='city'),
		"t_teams": Team.objects.filter(team_name__istartswith='t'),
		"bylocation_teams": Team.objects.all().order_by('location'),
		"reverse_teams": Team.objects.all().order_by('-team_name'),
		"cooper_players": Player.objects.filter(last_name__iexact='cooper'),
		"joshua_players": Player.objects.filter(first_name__iexact='joshua'),
		"cooper_nojoshua_players": Player.objects.filter(last_name__iexact='cooper').exclude(first_name__iexact='joshua'),
		"alexander_wyatt_players": Player.objects.filter(Q(first_name__iexact='alexander') | Q(first_name__iexact='wyatt')),
		"teams": Team.objects.all(),
		"players": Player.objects.all(),
	}
	return render(request, "leagues/index.html", context)

def make_data(request):
	team_maker.gen_leagues(10)
	team_maker.gen_teams(50)
	team_maker.gen_players(200)

	return redirect("index")